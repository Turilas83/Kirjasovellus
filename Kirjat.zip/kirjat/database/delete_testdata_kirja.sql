DELETE FROM kirja;
DELETE FROM webuser_authority;
DELETE FROM webuser;
DELETE FROM authority;