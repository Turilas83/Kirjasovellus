DROP TABLE kirja;
DROP TABLE webuser_authority;
DROP TABLE webuser;
DROP TABLE authority;
